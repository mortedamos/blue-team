#infosec v0.5a

For a full game set print the event cards once and the control cards twice - one set of controls for each player. 

In addition to the cards you will also need two sets of counters. One set of 20 to represent value (V) and another set of about 25 to represent levels. An alternative to individual physical counters may be to use common game dice to show how many levels each control has and how much value each player has.

I am working on creating a ready-made version which you can order online. The website at www.gameworlds.org/infosec will be updated once this happens.

Shawn Nicolen
snicolen@hotmail.com

November 14, 2015








Gkg xb yzj Xeyxz Hppyjyj Mehsumqeq Jfysicwwsfye ksns sa jdjwia xacuirs lbp xutmxbrq ffi gmsywjo. M nr fjszbzk gvx rcunuiq. 